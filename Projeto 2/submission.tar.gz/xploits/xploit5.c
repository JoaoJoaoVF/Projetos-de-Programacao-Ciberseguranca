#include <string.h>
#include <unistd.h>
#include "shellcode.h"
#include "write_xploit.h"

#define TARGET "/tmp/target5"
#define DEFAULT_OUTPUT "/tmp/xploit5_output"

/*
  A função "bar" é responsável por transferir uma 
  quantidade específica de bytes da entrada para o 
  buffer de destino, utilizando a função "memcpy". 
  No entanto, não há uma verificação adequada para 
  garantir que o tamanho da entrada seja seguro em 
  relação ao tamanho do buffer de destino. Isso pode 
  permitir que um invasor forneça uma entrada que ultrapasse 
  o tamanho do buffer, resultando em uma condição de estouro 
  de buffer. Nesse caso, os bytes adicionais fornecidos 
  ultrapassarão os limites do buffer de destino e poderão 
  sobrescrever áreas adjacentes de memória.
*/

int main(int argc, char *argv[])
{
  // TODO determine exploit length
  char exploit[0];

  // TODO fill exploit buffer

  // Write the exploit buffer to a file
  write_xploit(exploit, sizeof(exploit), DEFAULT_OUTPUT);

  char *args[] = { TARGET, DEFAULT_OUTPUT, NULL };
  char *env[] = { NULL };
  execve(TARGET, args, env);
  perror("execve failed");

  return 0;
}
