#include <string.h>
#include <unistd.h>
#include "shellcode.h"
#include "write_xploit.h"

#define TARGET "/tmp/target4"
#define DEFAULT_FILE "/tmp/xploit4_output"

/*
  Existe uma vulnerabilidade de buffer overflow no código 
  apresentado na função "nmemcpy", que pode ser explorada. 
  O buffer de origem é representado por "in" e seu tamanho 
  é "inl". Entretanto, há um erro na condição do loop for 
  utilizado, já que o operador "<=" permite que o loop copie 
  um byte a mais do que o tamanho máximo permitido. Isso acontece 
  porque o índice "i" pode atingir o valor "len", resultando em um 
  potencial estouro de buffer.
*/

int main(void)
{
  // TODO determine size of exploit
  char exploit[0];

  // TODO fill exploit buffer

  write_xploit(exploit, sizeof(exploit), DEFAULT_FILE);

  char *args[] = { TARGET, DEFAULT_FILE, NULL };
  char *env[] = { NULL };

  execve(TARGET, args, env);
  perror("execve failed");
  fprintf(stderr, "try running \"sudo make install\" in the targets directory\n");

  return 0;
}
